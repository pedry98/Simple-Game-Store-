﻿namespace GameStore_final
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.view_Shooters_Strategy = new System.Windows.Forms.Button();
            this.view_RPG_Multiplayer = new System.Windows.Forms.Button();
            this.view_trending = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Strategy = new System.Windows.Forms.GroupBox();
            this.cb13 = new System.Windows.Forms.CheckBox();
            this.cb12 = new System.Windows.Forms.CheckBox();
            this.cb11 = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.Shooters = new System.Windows.Forms.GroupBox();
            this.cb10 = new System.Windows.Forms.CheckBox();
            this.Multiplayer = new System.Windows.Forms.GroupBox();
            this.cb9 = new System.Windows.Forms.CheckBox();
            this.cb8 = new System.Windows.Forms.CheckBox();
            this.cb7 = new System.Windows.Forms.CheckBox();
            this.RPG = new System.Windows.Forms.GroupBox();
            this.cb6 = new System.Windows.Forms.CheckBox();
            this.cb5 = new System.Windows.Forms.CheckBox();
            this.cb4 = new System.Windows.Forms.CheckBox();
            this.Trending = new System.Windows.Forms.GroupBox();
            this.cb3 = new System.Windows.Forms.CheckBox();
            this.cb2 = new System.Windows.Forms.CheckBox();
            this.cb1 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Strategy.SuspendLayout();
            this.Shooters.SuspendLayout();
            this.Multiplayer.SuspendLayout();
            this.RPG.SuspendLayout();
            this.Trending.SuspendLayout();
            this.SuspendLayout();
            // 
            // view_Shooters_Strategy
            // 
            this.view_Shooters_Strategy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view_Shooters_Strategy.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.view_Shooters_Strategy.Location = new System.Drawing.Point(675, 265);
            this.view_Shooters_Strategy.Name = "view_Shooters_Strategy";
            this.view_Shooters_Strategy.Size = new System.Drawing.Size(75, 124);
            this.view_Shooters_Strategy.TabIndex = 26;
            this.view_Shooters_Strategy.Text = "View";
            this.view_Shooters_Strategy.UseVisualStyleBackColor = true;
            // 
            // view_RPG_Multiplayer
            // 
            this.view_RPG_Multiplayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view_RPG_Multiplayer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.view_RPG_Multiplayer.Location = new System.Drawing.Point(675, 144);
            this.view_RPG_Multiplayer.Name = "view_RPG_Multiplayer";
            this.view_RPG_Multiplayer.Size = new System.Drawing.Size(75, 103);
            this.view_RPG_Multiplayer.TabIndex = 25;
            this.view_RPG_Multiplayer.Text = "View";
            this.view_RPG_Multiplayer.UseVisualStyleBackColor = true;
            this.view_RPG_Multiplayer.Click += new System.EventHandler(this.view_RPG_Multiplayer_Click);
            // 
            // view_trending
            // 
            this.view_trending.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view_trending.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.view_trending.Location = new System.Drawing.Point(675, 68);
            this.view_trending.Name = "view_trending";
            this.view_trending.Size = new System.Drawing.Size(75, 70);
            this.view_trending.TabIndex = 24;
            this.view_trending.Text = "View";
            this.view_trending.UseVisualStyleBackColor = true;
            this.view_trending.Click += new System.EventHandler(this.view_trending_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(624, 404);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(52, 33);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // Strategy
            // 
            this.Strategy.Controls.Add(this.cb13);
            this.Strategy.Controls.Add(this.cb12);
            this.Strategy.Controls.Add(this.cb11);
            this.Strategy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Strategy.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Strategy.Location = new System.Drawing.Point(320, 259);
            this.Strategy.Name = "Strategy";
            this.Strategy.Size = new System.Drawing.Size(357, 130);
            this.Strategy.TabIndex = 22;
            this.Strategy.TabStop = false;
            this.Strategy.Text = "Strategy";
            // 
            // cb13
            // 
            this.cb13.AutoSize = true;
            this.cb13.Location = new System.Drawing.Point(24, 85);
            this.cb13.Name = "cb13";
            this.cb13.Size = new System.Drawing.Size(161, 20);
            this.cb13.TabIndex = 21;
            this.cb13.Text = "Man Of War - $4.99";
            this.cb13.UseVisualStyleBackColor = true;
            // 
            // cb12
            // 
            this.cb12.AutoSize = true;
            this.cb12.Location = new System.Drawing.Point(24, 59);
            this.cb12.Name = "cb12";
            this.cb12.Size = new System.Drawing.Size(150, 20);
            this.cb12.TabIndex = 20;
            this.cb12.Text = "Yu-Gi-Oh - $19.99";
            this.cb12.UseVisualStyleBackColor = true;
            // 
            // cb11
            // 
            this.cb11.AutoSize = true;
            this.cb11.Location = new System.Drawing.Point(24, 33);
            this.cb11.Name = "cb11";
            this.cb11.Size = new System.Drawing.Size(211, 20);
            this.cb11.TabIndex = 19;
            this.cb11.Text = "Football Manager - $49.99";
            this.cb11.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(502, 404);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(138, 33);
            this.button2.TabIndex = 21;
            this.button2.Text = "Check Out";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Shooters
            // 
            this.Shooters.Controls.Add(this.label2);
            this.Shooters.Controls.Add(this.cb10);
            this.Shooters.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Shooters.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Shooters.Location = new System.Drawing.Point(76, 259);
            this.Shooters.Name = "Shooters";
            this.Shooters.Size = new System.Drawing.Size(237, 130);
            this.Shooters.TabIndex = 19;
            this.Shooters.TabStop = false;
            this.Shooters.Text = "Shooters";
            // 
            // cb10
            // 
            this.cb10.AutoSize = true;
            this.cb10.Location = new System.Drawing.Point(14, 19);
            this.cb10.Name = "cb10";
            this.cb10.Size = new System.Drawing.Size(219, 20);
            this.cb10.TabIndex = 0;
            this.cb10.Text = "Call of Duty Boundle $99.99";
            this.cb10.UseVisualStyleBackColor = true;
            // 
            // Multiplayer
            // 
            this.Multiplayer.Controls.Add(this.cb9);
            this.Multiplayer.Controls.Add(this.cb8);
            this.Multiplayer.Controls.Add(this.cb7);
            this.Multiplayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Multiplayer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Multiplayer.Location = new System.Drawing.Point(320, 144);
            this.Multiplayer.Name = "Multiplayer";
            this.Multiplayer.Size = new System.Drawing.Size(357, 103);
            this.Multiplayer.TabIndex = 20;
            this.Multiplayer.TabStop = false;
            this.Multiplayer.Text = "Multiplayer";
            // 
            // cb9
            // 
            this.cb9.AutoSize = true;
            this.cb9.Location = new System.Drawing.Point(14, 62);
            this.cb9.Name = "cb9";
            this.cb9.Size = new System.Drawing.Size(188, 20);
            this.cb9.TabIndex = 3;
            this.cb9.Text = "Dark and Light - $29.99";
            this.cb9.UseVisualStyleBackColor = true;
            // 
            // cb8
            // 
            this.cb8.AutoSize = true;
            this.cb8.Location = new System.Drawing.Point(14, 39);
            this.cb8.Name = "cb8";
            this.cb8.Size = new System.Drawing.Size(111, 20);
            this.cb8.TabIndex = 2;
            this.cb8.Text = "Arc - $59.99";
            this.cb8.UseVisualStyleBackColor = true;
            // 
            // cb7
            // 
            this.cb7.AutoSize = true;
            this.cb7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb7.Location = new System.Drawing.Point(14, 16);
            this.cb7.Name = "cb7";
            this.cb7.Size = new System.Drawing.Size(293, 20);
            this.cb7.TabIndex = 1;
            this.cb7.Text = "Player Unknown Battleground- $ 29.99";
            this.cb7.UseVisualStyleBackColor = true;
            // 
            // RPG
            // 
            this.RPG.Controls.Add(this.cb6);
            this.RPG.Controls.Add(this.cb5);
            this.RPG.Controls.Add(this.cb4);
            this.RPG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RPG.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.RPG.Location = new System.Drawing.Point(76, 144);
            this.RPG.Name = "RPG";
            this.RPG.Size = new System.Drawing.Size(237, 103);
            this.RPG.TabIndex = 18;
            this.RPG.TabStop = false;
            this.RPG.Text = "RPG";
            // 
            // cb6
            // 
            this.cb6.AutoSize = true;
            this.cb6.Location = new System.Drawing.Point(3, 62);
            this.cb6.Name = "cb6";
            this.cb6.Size = new System.Drawing.Size(161, 20);
            this.cb6.TabIndex = 2;
            this.cb6.Text = "Dragon Age- $4.99";
            this.cb6.UseVisualStyleBackColor = true;
            // 
            // cb5
            // 
            this.cb5.AutoSize = true;
            this.cb5.Location = new System.Drawing.Point(3, 39);
            this.cb5.Name = "cb5";
            this.cb5.Size = new System.Drawing.Size(201, 20);
            this.cb5.TabIndex = 1;
            this.cb5.Text = "The Elder Scrolls-$29.99";
            this.cb5.UseVisualStyleBackColor = true;
            // 
            // cb4
            // 
            this.cb4.AutoSize = true;
            this.cb4.Location = new System.Drawing.Point(3, 16);
            this.cb4.Name = "cb4";
            this.cb4.Size = new System.Drawing.Size(168, 20);
            this.cb4.TabIndex = 0;
            this.cb4.Text = "The Witcher- $39.99";
            this.cb4.UseVisualStyleBackColor = true;
            // 
            // Trending
            // 
            this.Trending.Controls.Add(this.cb3);
            this.Trending.Controls.Add(this.cb2);
            this.Trending.Controls.Add(this.cb1);
            this.Trending.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Trending.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Trending.Location = new System.Drawing.Point(76, 68);
            this.Trending.Name = "Trending";
            this.Trending.Size = new System.Drawing.Size(601, 70);
            this.Trending.TabIndex = 17;
            this.Trending.TabStop = false;
            this.Trending.Text = "Trending";
            // 
            // cb3
            // 
            this.cb3.AutoSize = true;
            this.cb3.Location = new System.Drawing.Point(430, 34);
            this.cb3.Name = "cb3";
            this.cb3.Size = new System.Drawing.Size(156, 20);
            this.cb3.TabIndex = 18;
            this.cb3.Text = "PayDay 2 - $44.98";
            this.cb3.UseVisualStyleBackColor = true;
            // 
            // cb2
            // 
            this.cb2.AutoSize = true;
            this.cb2.Location = new System.Drawing.Point(205, 34);
            this.cb2.Name = "cb2";
            this.cb2.Size = new System.Drawing.Size(218, 20);
            this.cb2.TabIndex = 17;
            this.cb2.Text = "Grand Theft Auto V - $59.99";
            this.cb2.UseVisualStyleBackColor = true;
            // 
            // cb1
            // 
            this.cb1.AutoSize = true;
            this.cb1.Location = new System.Drawing.Point(14, 34);
            this.cb1.Name = "cb1";
            this.cb1.Size = new System.Drawing.Size(184, 20);
            this.cb1.TabIndex = 16;
            this.cb1.Text = "Counter Strike - $14.99";
            this.cb1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(70, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 25);
            this.label1.TabIndex = 16;
            this.label1.Text = "Games";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 48);
            this.label2.TabIndex = 5;
            this.label2.Text = "Ghost\r\nWorld War II\r\nBlack Ops III";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(805, 463);
            this.Controls.Add(this.view_Shooters_Strategy);
            this.Controls.Add(this.view_RPG_Multiplayer);
            this.Controls.Add(this.view_trending);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Strategy);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Shooters);
            this.Controls.Add(this.Multiplayer);
            this.Controls.Add(this.RPG);
            this.Controls.Add(this.Trending);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Steam Store";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Strategy.ResumeLayout(false);
            this.Strategy.PerformLayout();
            this.Shooters.ResumeLayout(false);
            this.Shooters.PerformLayout();
            this.Multiplayer.ResumeLayout(false);
            this.Multiplayer.PerformLayout();
            this.RPG.ResumeLayout(false);
            this.RPG.PerformLayout();
            this.Trending.ResumeLayout(false);
            this.Trending.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button view_Shooters_Strategy;
        private System.Windows.Forms.Button view_RPG_Multiplayer;
        private System.Windows.Forms.Button view_trending;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox Strategy;
        private System.Windows.Forms.CheckBox cb13;
        private System.Windows.Forms.CheckBox cb12;
        private System.Windows.Forms.CheckBox cb11;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox Shooters;
        private System.Windows.Forms.CheckBox cb10;
        private System.Windows.Forms.GroupBox Multiplayer;
        private System.Windows.Forms.CheckBox cb9;
        private System.Windows.Forms.CheckBox cb8;
        private System.Windows.Forms.CheckBox cb7;
        private System.Windows.Forms.GroupBox RPG;
        private System.Windows.Forms.CheckBox cb6;
        private System.Windows.Forms.CheckBox cb5;
        private System.Windows.Forms.CheckBox cb4;
        private System.Windows.Forms.GroupBox Trending;
        private System.Windows.Forms.CheckBox cb3;
        private System.Windows.Forms.CheckBox cb2;
        private System.Windows.Forms.CheckBox cb1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

