﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GameStore_final
{
    public partial class Form2 : Form
    {
        private double optionsCost;
        private string optionList;

        public double GetOptionsCost { set { optionsCost = value; } }
        public string GetOptionsList { set { optionList = value; } }


        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            double TaxAmount = optionsCost * 0.07;
            label2.Text = label2.Text + "02/01/2018";
            richTextBox1.Text = optionList;
            textBox1.Text = " $" + optionsCost.ToString();
            textBox2.Text = " $" + (TaxAmount).ToString();
            textBox3.Text = " $" + (optionsCost + TaxAmount).ToString();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
