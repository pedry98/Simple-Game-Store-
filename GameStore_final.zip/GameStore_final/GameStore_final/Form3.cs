﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GameStore_final
{
    public partial class Form3 : Form
    {
       
       
        public Form3()
        {
            InitializeComponent();
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
           
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form1 Menu = new Form1();
            this.Hide();
            Menu.Show();
        }
    }
}
