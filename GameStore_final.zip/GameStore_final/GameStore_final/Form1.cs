﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GameStore_final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double Cost = 0;
            string Items = "";
            Form2 s = new Form2();


            s.GetOptionsList = "";

            s.GetOptionsCost = 0;
            s.GetOptionsList = Items;
            if (cb1.Checked == true)
            {
                Cost = Cost + 14.99;
                Items = Items + Environment.NewLine + cb1.Text;
            }
            if (cb2.Checked == true)
            {
                Cost = Cost + 59.99;
                Items = Items + Environment.NewLine + cb2.Text;
            }
            if (cb3.Checked == true)
            {
                Cost = Cost + 44.98;
                Items = Items + Environment.NewLine + cb3.Text;
            }
            if (cb4.Checked == true)
            {
                Cost = Cost + 39.99;
                Items = Items + Environment.NewLine + cb4.Text;
            }
            if (cb5.Checked == true)
            {
                Cost = Cost + 29.99;
                Items = Items + Environment.NewLine + cb5.Text;
            }
            if (cb6.Checked == true)
            {
                Cost = Cost + 4.99;
                Items = Items + Environment.NewLine + cb6.Text;
            }
            if (cb7.Checked == true)
            {
                Cost = Cost + 29.99;
                Items = Items + Environment.NewLine + cb7.Text;
            }
            if (cb8.Checked == true)
            {
                Cost = Cost + 59.99;
                Items = Items + Environment.NewLine + cb8.Text;
            }
            if (cb9.Checked == true)
            {
                Cost = Cost + 29.99;
                Items = Items + Environment.NewLine + cb9.Text;
            }
            if (cb10.Checked == true)
            {
                Cost = Cost + 99.99;
                Items = Items + Environment.NewLine + cb10.Text;
            }
            if (cb11.Checked == true)
            {
                Cost = Cost + 49.99;
                Items = Items + Environment.NewLine + cb11.Text;
            }
            if (cb12.Checked == true)
            {
                Cost = Cost + 19.99;
                Items = Items + Environment.NewLine + cb12.Text;
            }
            if (cb13.Checked == true)
            {
                Cost = Cost + 4.99;
                Items = Items + Environment.NewLine + cb13.Text;
            }

            if (Items == "")
            {
                MessageBox.Show("You didn't select any options.\nPlease Make a selection.");

            }
            else
            {
                s.GetOptionsCost = Cost;
                s.GetOptionsList = Items;
                s.ShowDialog();
            }
        }

        private void view_trending_Click(object sender, EventArgs e)
        {
            Form3 trending = new Form3();
            this.Hide();
            trending.Show();
        }

        private void view_RPG_Multiplayer_Click(object sender, EventArgs e)
        {
        }
    }
}
